# Authenticate_QA_Assessment

# E-commerce Assement 

## Setup

1. Create the Project
2. Run "npm install" to install dependencies
3. Cypress Installation by "npm install cypress"
4. Verify Cypress by "npx cypress verify"
5. Create a new file "spec.cy.js"
6. To run the File using Cypress = "npx cypress open"
## for any issue feel free to mail me at gaurav.singh020499@gmail.com
